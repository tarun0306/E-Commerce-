export enum CategoryType {
    "Books", "Electronics", "Clothes", "Drink"
}

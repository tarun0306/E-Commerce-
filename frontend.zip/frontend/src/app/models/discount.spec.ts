import { Discount } from './discount';

describe('Discount', () => {
  it('should create an instance', () => {
    expect(new Discount()).toBeTruthy();
  });
});

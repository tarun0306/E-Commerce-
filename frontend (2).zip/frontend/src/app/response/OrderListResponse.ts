import { Order } from "../models/Order";

export class OrderListResponse {
    orderList : Order[]

}


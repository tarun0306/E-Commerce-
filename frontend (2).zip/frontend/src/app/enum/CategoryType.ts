export enum CategoryType {
    // "Books", "Electronics", "Clothes", "Drink"
    "Asthetic Mirrors","Beds","Sofa & Recliners","Wall Accents"
}

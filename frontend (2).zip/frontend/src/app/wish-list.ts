export class WishList {
}
